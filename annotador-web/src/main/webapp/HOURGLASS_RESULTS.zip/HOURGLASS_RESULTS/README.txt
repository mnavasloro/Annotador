-----------------
RESULTS
-----------------

These are the results by thre temporal taggers on the HourGlass corpus.


-----------------
FOLDER STRUCTURE
-----------------

In this folder you will find:
- result_GATE/
---- 348 .xml files with the annotations of the three taggers and the key annotations that can be loaded into GATE to facilitate visualization and comparison.

- results_Annotador/
---- 348 .tml files with the tags by Annotador.

- results_Heidel/
---- 348 .tml files with the tags by Heideltime.

- results_SUTime/
---- 348 .tml files with the tags by SUTime.

- README.txt

